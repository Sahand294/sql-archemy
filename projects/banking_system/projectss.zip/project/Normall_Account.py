import Bank_Account as Banks


class NormalAccount(Banks):
    def __init__(self, bank_holder, account_number, password):
        super().__init__(bank_holder, account_number, password)
