import Bank_Account as Bank

class CheckingAccount(Bank):
    def __init__(self, account_holder, account_number, password, withdrawlimit):
        self.total_Review = {'owner': account_holder, 'id': account_number, 'balance': 0.0, 'type': 'checking',
                             'withdraw limit': withdrawlimit}
        super().__init__(account_holder, account_number, password)
        self.limit = withdrawlimit

    def withrawing(self, money, password):
        if self.limit < money:
            raise Exception(f"you have hit the withdraw limit")
        super().withrawing(money, password)