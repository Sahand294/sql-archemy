
import Bank_Account as Bank

class SavingsAccount(Bank):
    def __init__(self, bank_holder, account_Number, password, intrest_Rate):
        self.total_Review = {'owner': bank_holder, 'id': account_Number, 'balance': 0.0, 'type': 'savings',
                             'interest rate': intrest_Rate}
        super().__init__(bank_holder, account_Number, password)
        self.intrestrate = intrest_Rate

    def applyintrest(self, account_file):
        self.deposit(self.check_money() * (self.intrestrate / 100.0), account_file)