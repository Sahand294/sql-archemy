
from Normall_Account import NormalAccount
from Savings_Account import SavingsAccount
from Cheking_Account import CheckingAccount
class Bank:
    def __init__(self):
        self.accounts = {}

    def addaccounts(self, account_Type, account_holder, account_number, password, **kwargs_):
        if account_Type == 'cheking':
            account = CheckingAccount(account_holder, account_number, password, kwargs_.get('withdrawlimit', 500))
        if account_Type == 'saving':
            account = SavingsAccount(account_holder, account_number, password, kwargs_.get('intrestrate', 5))
        if account_Type == 'normall':
            account = NormalAccount(account_holder, account_number, password)
        self.accounts[account_number] = account

    def authenticate(self, account_numbers, password):
        id = account_numbers
        if account_numbers not in self.accounts:
            raise ValueError(f'there is no such account!')

        if password != self.accounts[id]['password']:
            raise ValueError(f'incorrect password')
        account = self.accounts
bank = Bank()
account11 = bank.addaccounts("saving",55, 95849, 'hey', intrestrate=5)

account22 =  bank.addaccounts('saving', 989, 'hello world', 500, withdrawlimit=300)
account1 =  bank.accounts[95849]
account1.transfer(100,"bank_account.csv")