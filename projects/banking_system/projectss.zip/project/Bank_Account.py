import csv


class BankAccount:
    def __init__(self, bank_holder, account_number, password):
        self.bank_holder = bank_holder
        self.account_number = account_number
        self.password = password
        self.total_Review = {'owner': self.bank_holder, 'id': self.account_number, 'balance': self.check_money()}

        with open("bank_account.csv", 'r', encoding="utf-8") as text1:
            if f"{account_number}" in text1.read():
                pass
            else:
                with open("bank_account.csv", 'a', encoding="utf-8") as text:
                    text.write(f'\n{self.total_Review}')

    def check_money(self):
        with open("bank_account.csv", 'r', encoding="utf-8") as text1:
            r = csv.DictReader(text1)
            data = []
            for i in r:
                file = {key: value.strip() for key, value in i.items()}
                data.append(file)
            for i in data:
                if i["id"] == str(self.account_number):
                    balance = i["balance"]
            return float(balance)

    def deposit(self, money, address_file: str):

        with open(address_file, 'r', encoding="utf-8") as file:
            r = csv.DictReader(file)
            data = []
            for i in r:
                files = {key: value.strip() for key, value in i.items()}
                data.append(files)
        for x, i in enumerate(data):
            if i['id'] == str(self.account_number):
                data[x]['balance'] = float(data[x]['balance']) + money
        with open(address_file, "w", encoding="utf-8", newline="") as text:
            file = data[0].keys()
            writer = csv.DictWriter(text, fieldnames=file)
            writer.writeheader()
            writer.writerows(data)

        with open(f"transaction", 'a') as text:
            text.write(f'\n{self.account_number} has deposited {money}$  balance:{self.check_money()}')

    def check_password(self):
        with open("bank_account.csv", 'r', encoding="utf-8") as text1:
            r = csv.DictReader(text1)
            data = []
            for i in r:
                file = {key: value.strip() for key, value in i.items()}
                data.append(file)
            for i in data:
                if i["id"] == str(self.account_number):
                    balance = i["password"]
            return str(balance)

    def withrawing(self, money, password):

        if password != self.check_password():
            raise ValueError("its incorrect")
        if self.check_money() >= money:
            pass
        else:
            raise ValueError(f'not enough money')
        print('withdraw implementing subclass')
        with open(f"transaction", 'a') as text:
            text.write(f'\n{self.account_number} has withdraw {money}$  balance:{self.check_money()}')

        with open("bank_account.csv", 'r', encoding="utf-8") as file:
            r = csv.DictReader(file)
            data = []
            for i in r:
                files = {key: value.strip() for key, value in i.items()}
                data.append(files)
        for x, i in enumerate(data):
            if i['id'] == str(self.account_number):
                data[x]['balance'] = float(data[x]['balance']) - money
        with open("bank_account.csv", "w", encoding="utf-8", newline="") as text:
            file = data[0].keys()
            writer = csv.DictWriter(text, fieldnames=file)
            writer.writeheader()
            writer.writerows(data)

    def transfer(self, money, target_account, password, account_file):


        with open(f"transaction", 'a') as text:
            text.write(
                f'\n{self.account_number} has transferred {money}$ from {self.account_number} to {target_account} balance:{self.check_money()}')

        self.withrawing(money, password)
        target_account.deposit(money, account_file)

        with open(f"transaction", 'a') as text:
            text.write(
                f'\n{self.account_number} has transferred {money}$ from {self.account_number} to {target_account} balance:{self.check_money()}')

    def review(self):
        return {'owner': self.bank_holder, 'id': self.account_number, 'balance': self.check_money()}
